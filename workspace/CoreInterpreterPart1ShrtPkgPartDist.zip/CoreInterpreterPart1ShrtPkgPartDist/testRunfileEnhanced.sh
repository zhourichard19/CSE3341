#!/bin/bash
./runfilebased.sh RunfileEnhanced dataEnhanced
