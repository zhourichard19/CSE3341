package edu.c3341;

/**
 * Responsible for the <prog> non-terminal symbol of the context-free grammar
 * for the Core programming language.
 *
 * @author Wayne Heym
 *
 */
final class IdList {
    /**
     * The declaration sequence.
     */
    private IdList idl;

    /**
     * The main statement sequence.
     */
    private Id id;
    /**
     * The main statement sequence.
     */
    private TokenKind kind;

    /**
     * Parses a Core program into this object.
     *
     */
    public void parseIdl() {
        this.id = Id.parseId();
        this.kind = Tokenizer1.instance().getToken();
        if (this.kind == TokenKind.COMMA) {
            Tokenizer1.instance().skipToken();
            this.idl = new IdList();
            this.idl.parseIdl();
        }
    }

    /**
     * Pretty prints a Core program indented by indent spaces.
     *
     */
    public void printIdl() {
        this.id.printId();
        if (this.kind == TokenKind.COMMA) {
            System.out.print(", ");
            this.idl.printIdl();
        }
    }

    /**
     * Executes a Core program.
     */
    public void execIdl() {
        this.id.execId();
        if (this.kind == TokenKind.COMMA) {
            this.idl.execIdl();
        }
    }

    public void readIdl() {
        this.id.readId();
        if (this.idl != null) {
            this.idl.readIdl();
        }
    }

    public void writeIdl() {
        System.out.println(this.id.getIdName() + " = " + this.id.getIdVal());
        if (this.kind == TokenKind.COMMA) {
            this.idl.writeIdl();
        }
    }

}
