package edu.c3341;

/**
 * Responsible for the <prog> non-terminal symbol of the context-free grammar
 * for the Core programming language.
 *
 * @author Wayne Heym
 *
 */
final class Exp {
    /**
     * The declaration sequence.
     */
    private Term t;

    /**
     * The main statement sequence.
     */
    private Exp e;
    /**
     * The main statement sequence.
     */
    private TokenKind kind;

    /**
     * Parses a Core program into this object.
     *
     */
    public void parseExp() {
        this.t = new Term();
        this.t.parseTerm();
        this.kind = Tokenizer1.instance().getToken();
        Tokenizer t = Tokenizer1.instance();

        if (this.kind == TokenKind.ADDITION
                || this.kind == TokenKind.SUBTRACTION) {
            t.skipToken();
            this.e = new Exp();
            this.e.parseExp();
        }
    }

    /**
     * Pretty prints a Core program indented by indent spaces.
     *
     */
    public void printExp() {
        this.t.printTerm();
        if (this.kind == TokenKind.SUBTRACTION) {
            System.out.print(" - ");
            this.e.printExp();
        } else if (this.kind == TokenKind.ADDITION) {
            System.out.print(" + ");
            this.e.printExp();
        }
    }

    /**
     * Executes a Core program.
     */
    public int execExp() {
        int r = this.t.execTerm();
        if (this.kind == TokenKind.ADDITION) {
            r += this.e.execExp();
        } else if (this.kind == TokenKind.SUBTRACTION) {
            r -= this.e.execExp();
        }
        return r;
    }

}
