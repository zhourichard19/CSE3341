package edu.c3341;

/**
 * Responsible for the <prog> non-terminal symbol of the context-free grammar
 * for the Core programming language.
 *
 * @author Wayne Heym
 *
 */
final class In {
    /**
     * The declaration sequence.
     */
    private IdList idl;

    /**
     * Parses a Core program into this object.
     *
     */
    public void parseIn() {
        Tokenizer t = Tokenizer1.instance();
        this.idl = new IdList();
        if (!t.isKind(TokenKind.READ)) {
            t.errMsg("Expected: read");
        }
        this.idl.parseIdl();
        if (!t.isKind(TokenKind.SEMICOLON)) {
            t.errMsg("Expected: ;");
        }
    }

    /**
     * Pretty prints a Core program indented by indent spaces.
     *
     */
    public void printIn() {
        System.out.print("read ");
        this.idl.printIdl();
        System.out.print(";");
    }

    /**
     * Executes a Core program.
     */
    public void execIn() {
        this.idl.readIdl();
    }

}
