package edu.c3341;

/**
 * Responsible for the <prog> non-terminal symbol of the context-free grammar
 * for the Core programming language.
 *
 * @author Wayne Heym
 *
 */
final class StmtSeq {
    /**
     * The declaration sequence.
     */
    private StmtSeq ss;

    /**
     * The main statement sequence.
     */
    private Stmt s;
    /**
     * The main statement sequence.
     */
    private TokenKind kind;

    /**
     * Parses a Core program into this object.
     *
     */
    public void parseSS() {
        this.s = new Stmt();
        this.s.parseS();
        this.kind = Tokenizer1.instance().getToken();

        if (this.kind != TokenKind.END && this.kind != TokenKind.ELSE) {
            this.ss = new StmtSeq();
            this.ss.parseSS();
        }
    }

    /**
     * Pretty prints a Core program indented by indent spaces.
     */
    public void printSS(int n) {
        String whitespace = String.format("%" + n + "s", "");
        System.out.print("\n" + whitespace);
        this.s.printS(n);

        if (this.kind != TokenKind.END && this.kind != TokenKind.ELSE) {
            this.ss.printSS(n);
        }
    }

    /**
     * Executes a Core program.
     */
    public void execSS() {
        this.s.execS();
        if (this.kind != TokenKind.END && this.kind != TokenKind.ELSE) {
            this.ss.execSS();
        }
    }

}
