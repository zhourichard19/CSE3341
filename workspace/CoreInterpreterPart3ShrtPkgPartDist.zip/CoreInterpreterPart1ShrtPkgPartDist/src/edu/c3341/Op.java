package edu.c3341;

/**
 * Responsible for the <prog> non-terminal symbol of the context-free grammar
 * for the Core programming language.
 *
 * @author Wayne Heym
 *
 */
final class Op {
    /**
     * The declaration sequence.
     */
    private No n;

    /**
     * The main statement sequence.
     */
    private Id id;
    /**
     * The main statement sequence.
     */
    private Exp e;

    /**
     * The main statement sequence.
     */
    private TokenKind kind;

    /**
     * Parses a Core program into this object.
     *
     */
    public void parseOp() {
        this.kind = Tokenizer1.instance().getToken();
        Tokenizer t = Tokenizer1.instance();

        if (this.kind == TokenKind.INTEGER_CONSTANT) {
            this.n = new No();
            this.n.parseNo();
        } else if (this.kind == TokenKind.IDENTIFIER) {
            this.id = Id.parseId();
        } else if (this.kind == TokenKind.FORWARD_PARENTHESIS) {
            t.skipToken();
            this.e = new Exp();
            this.e.parseExp();
            if (!t.isKind(TokenKind.BACKWARD_PARENTHESIS)) {
                t.errMsg("Error: )");
            }
        } else {
            t.errMsg("Should be a number or an identifier");
        }
    }

    /**
     * Pretty prints a Core program indented by indent spaces.
     *
     */
    public void printOp() {
        if (this.kind == TokenKind.INTEGER_CONSTANT) {
            this.n.printNo();
        } else if (this.kind == TokenKind.IDENTIFIER) {
            this.id.printId();
        } else {
            System.out.print("(");
            this.e.printExp();
            System.out.print(")");
        }
    }

    /**
     * Executes a Core program.
     */
    public int execOp() {
        if (this.kind == TokenKind.IDENTIFIER) {
            return this.id.getIdVal();
        } else if (this.kind == TokenKind.INTEGER_CONSTANT) {
            return this.n.execNo();
        } else {
            return this.e.execExp();
        }
    }

}
