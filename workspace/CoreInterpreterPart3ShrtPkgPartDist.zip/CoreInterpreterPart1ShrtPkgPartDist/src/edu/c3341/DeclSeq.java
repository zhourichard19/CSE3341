package edu.c3341;

/**
 * Responsible for the <prog> non-terminal symbol of the context-free grammar
 * for the Core programming language.
 *
 * @author Wayne Heym
 *
 */
final class DeclSeq {
    /**
     * The declaration sequence.
     */
    private DeclSeq ds;

    /**
     * The main statement sequence.
     */
    private Decl d;
    /**
     * The main statement sequence.
     */
    private TokenKind kind;

    /**
     * Parses a Core program into this object.
     *
     */
    public void parseDS() {
        this.d = new Decl();
        this.d.parseD();
        this.kind = Tokenizer1.instance().getToken();
        if (this.kind != TokenKind.BEGIN) {
            this.ds = new DeclSeq();
            this.ds.parseDS();
        }
    }

    /**
     * Pretty prints a Core program indented by indent spaces.
     */
    public void printDS(int n) {
        String whitespace = String.format("%" + n + "s", "");
        System.out.print("\n" + whitespace);
        this.d.printD();
        if (this.kind != TokenKind.BEGIN) {
            this.ds.printDS(n);
        }
    }

    /**
     * Executes a Core program.
     */
    public void execDS() {
        this.d.execD();
        if (this.kind != TokenKind.BEGIN) {
            this.ds.execDS();
        }
    }

}
