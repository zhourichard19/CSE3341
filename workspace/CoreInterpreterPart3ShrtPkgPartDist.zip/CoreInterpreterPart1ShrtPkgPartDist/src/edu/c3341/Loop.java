package edu.c3341;

/**
 * Responsible for the <prog> non-terminal symbol of the context-free grammar
 * for the Core programming language.
 *
 * @author Wayne Heym
 *
 */
final class Loop {
    /**
     * The declaration sequence.
     */
    private Cond c;

    /**
     * The main statement sequence.
     */
    private StmtSeq s;

    /**
     * Parses a Core program into this object.
     *
     */
    public void parseLoop() {
        Tokenizer t = Tokenizer1.instance();
        if (!t.isKind(TokenKind.WHILE)) {
            t.errMsg("Error: while");
        }
        this.c = new Cond();
        this.c.parseCond();
        if (!t.isKind(TokenKind.LOOP)) {
            t.errMsg("Error: loop");
        }
        this.s = new StmtSeq();
        this.s.parseSS();
        if (!t.isKind(TokenKind.END)) {
            t.errMsg("Error: end");
        }
        if (!t.isKind(TokenKind.SEMICOLON)) {
            t.errMsg("Error: ;");
        }
    }

    /**
     * Pretty prints a Core program indented by indent spaces.
     *
     */
    public void printLoop(int n) {
        System.out.print("while ");
        this.c.printCond();
        System.out.print("loop");
        this.s.printSS(n + 2);
        String whitespace = String.format("%" + n + "s", "");
        System.out.print("\n" + whitespace);
        System.out.print("end;");
    }

    /**
     * Executes a Core program.
     */
    public void execLoop() {
        Boolean c = this.c.execCond();
        while (c == true) {
            this.s.execSS();
            c = this.c.execCond();
        }
    }

}
