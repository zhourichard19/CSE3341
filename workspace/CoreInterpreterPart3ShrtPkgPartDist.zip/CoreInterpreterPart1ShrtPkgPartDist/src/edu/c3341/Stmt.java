package edu.c3341;

/**
 * Responsible for the <prog> non-terminal symbol of the context-free grammar
 * for the Core programming language.
 *
 * @author Wayne Heym
 *
 */
final class Stmt {
    private Assign s1;

    private If s2;

    private Loop s3;

    private In s4;

    private Out s5;

    private TokenKind kind;

    /**
     * Parses a Core program into this object.
     *
     */
    public void parseS() {
        this.kind = Tokenizer1.instance().getToken();
        if (this.kind == TokenKind.IDENTIFIER) {
            this.s1 = new Assign();
            this.s1.parseAssign();
        } else if (this.kind == TokenKind.IF) {
            this.s2 = new If();
            this.s2.parseIf();
        } else if (this.kind == TokenKind.WHILE) {
            this.s3 = new Loop();
            this.s3.parseLoop();
        } else if (this.kind == TokenKind.READ) {
            this.s4 = new In();
            this.s4.parseIn();
        } else if (this.kind == TokenKind.WRITE) {
            this.s5 = new Out();
            this.s5.parseOut();
        } else {
            Tokenizer1.instance()
                    .errMsg("Should be an if write assign or stmt");
        }
    }

    /**
     * Pretty prints a Core program indented by indent spaces.
     *
     * @param indent
     *            Number of spaces with which to indent Core program.
     */
    public void printS(int n) {
        if (this.kind == TokenKind.IDENTIFIER) {
            this.s1.printAssign();
        } else if (this.kind == TokenKind.IF) {
            this.s2.printIf(n);
        } else if (this.kind == TokenKind.WHILE) {
            this.s3.printLoop(n);
        } else if (this.kind == TokenKind.READ) {
            this.s4.printIn();
        } else {
            this.s5.printOut();
        }
    }

    /**
     * Executes a Core program.
     */
    public void execS() {
        if (this.kind == TokenKind.IDENTIFIER) {
            this.s1.execAssign();
        } else if (this.kind == TokenKind.IF) {
            this.s2.execIf();
        } else if (this.kind == TokenKind.WHILE) {
            this.s3.execLoop();
        } else if (this.kind == TokenKind.READ) {
            this.s4.execIn();
        } else {
            this.s5.execOut();
        }
    }

}
