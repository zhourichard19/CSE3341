package edu.c3341;

/**
 * Responsible for the <prog> non-terminal symbol of the context-free grammar
 * for the Core programming language.
 *
 * @author Wayne Heym
 *
 */
final class Cond {
    /**
     * The declaration sequence.
     */
    private Comp comp;

    /**
     * The main statement sequence.
     */
    private Cond c1;

    /**
     * The main statement sequence.
     */
    private Cond c2;

    /**
     * The main statement sequence.
     */
    private TokenKind kind1;

    /**
     * The main statement sequence.
     */
    private TokenKind kind2;

    /**
     * Parses a Core program into this object.
     *
     */
    public void parseCond() {
        this.kind1 = Tokenizer1.instance().getToken();
        Tokenizer t = Tokenizer1.instance();

        if (this.kind1 == TokenKind.EXCLAMATION
                || this.kind1 == TokenKind.FORWARD_BRACKET) {
            t.skipToken();

            this.c1 = new Cond();
            this.c1.parseCond();
            this.kind2 = Tokenizer1.instance().getToken();

            if (this.kind2 == TokenKind.AND_OPERATOR
                    || this.kind2 == TokenKind.OR_OPERATOR) {
                t.skipToken();
                this.c2 = new Cond();
                this.c2.parseCond();
                if (!t.isKind(TokenKind.BACKWARD_BRACKET)) {
                    t.errMsg("]");
                }
            }
        } else {
            this.comp = new Comp();
            this.comp.parseComp();
        }

    }

    /**
     * Pretty prints a Core program indented by indent spaces.
     *
     */
    public void printCond() {
        if (this.kind1 == TokenKind.FORWARD_PARENTHESIS) {
            this.comp.printComp();
        } else if (this.kind1 == TokenKind.FORWARD_BRACKET) {
            System.out.print("[");
            this.c1.printCond();
            if (this.kind2 == TokenKind.AND_OPERATOR) {
                System.out.print(" && ");
            } else {
                System.out.print(" or ");
            }
            this.c2.printCond();
            System.out.print("]");
        } else {
            System.out.print("!");
            this.c1.printCond();
        }
    }

    /**
     * Executes a Core program.
     */
    public boolean execCond() {
        if (this.kind1 == TokenKind.FORWARD_PARENTHESIS) {
            return this.comp.execComp();
        } else if (this.kind1 == TokenKind.FORWARD_BRACKET) {
            boolean c = this.c1.execCond();
            if (this.kind2 == TokenKind.AND_OPERATOR) {
                return c && this.c2.execCond();
            } else {
                return c || this.c2.execCond();
            }
        } else {
            return !this.c1.execCond();
        }
    }

}
