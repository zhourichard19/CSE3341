package edu.c3341;

/**
 * Responsible for the <prog> non-terminal symbol of the context-free grammar
 * for the Core programming language.
 *
 * @author Wayne Heym
 *
 */
final class Term {
    /**
     * The declaration sequence.
     */
    private Op o;

    /**
     * The main statement sequence.
     */
    private Term t;
    /**
     * The main statement sequence.
     */
    private TokenKind kind;

    /**
     * Parses a Core program into this object.
     *
     */
    public void parseTerm() {
        this.o = new Op();
        this.o.parseOp();
        this.kind = Tokenizer1.instance().getToken();

        if (this.kind == TokenKind.MULTIPLICATION) {
            Tokenizer1.instance().skipToken();
            this.t = new Term();
            this.t.parseTerm();
        }
    }

    /**
     * Pretty prints a Core program indented by indent spaces.
     *
     */
    public void printTerm() {
        this.o.printOp();
        if (this.kind == TokenKind.MULTIPLICATION) {
            System.out.print(" * ");
            this.t.printTerm();
        }
    }

    /**
     * Executes a Core program.
     */
    public int execTerm() {
        int r = this.o.execOp();
        if (this.kind == TokenKind.MULTIPLICATION) {
            r += this.t.execTerm();
        }
        return r;
    }

}
