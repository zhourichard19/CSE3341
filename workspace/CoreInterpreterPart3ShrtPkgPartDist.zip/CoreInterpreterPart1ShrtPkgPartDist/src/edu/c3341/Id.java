package edu.c3341;

import java.util.Iterator;

/**
 * Responsible for the <prog> non-terminal symbol of the context-free grammar
 * for the Core programming language.
 *
 * @author Wayne Heym
 *
 */
final class Id {
    private String name;
    private int val;
    private boolean declared;
    private boolean initialized;
    private static Id eIds[] = new Id[20];
    private static int idCount = 0;
    private static Iterator<String> data;

    private Id(String s) {
        this.name = s;
        this.declared = false;
        this.initialized = false;
    }

    public static Id parseId() {
        String Idname = Tokenizer1.instance().idName();
        Tokenizer1.instance().skipToken();
        for (int i = 0; i < idCount; i++) {
            if (eIds[i].getIdName().equals(Idname)) {
                return eIds[i];
            }
        }
        Id nId = new Id(Idname);
        eIds[idCount] = nId;
        idCount++;
        return nId;
    }

    public int getIdVal() {
        Reporter.assertElseFatalError(this.declared,
                "Error: " + this.name + " needs to be declared");
        Reporter.assertElseFatalError(this.initialized,
                "Error: " + this.name + " needs to be initialized");
        return this.val;
    }

    public static void prepareRun(Iterator<String> d) {
        Id.data = d;
    }

    public static void prepareParse() {
        idCount = 0;
    }

    public void setIdVal(int n) {
        Reporter.assertElseFatalError(this.declared, "Error: " + this.name
                + " should be declared before being assigned");
        this.val = n;
        this.initialized = true;
    }

    public String getIdName() {
        return this.name;
    }

    public void printId() {
        System.out.print(this.name);

    }

    public void execId() {
        this.declared = true;
    }

    public void readId() {
        Reporter.assertElseFatalError(Id.data.hasNext(),
                "Did not find enough data");
        try {
            this.val = Integer.parseInt(Id.data.next());
            this.initialized = true;
        } catch (NumberFormatException e) {
            Reporter.fatalErrorToConsole("Did not find the right file");
        }

    }

}
