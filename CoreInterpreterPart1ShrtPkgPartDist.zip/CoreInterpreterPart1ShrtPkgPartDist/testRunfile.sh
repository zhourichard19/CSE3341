#!/bin/bash
./runfilebased.sh Runfile data
