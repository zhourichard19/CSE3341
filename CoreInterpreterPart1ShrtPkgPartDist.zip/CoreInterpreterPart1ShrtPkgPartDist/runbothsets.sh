#!/bin/bash
./testRunfile.sh
./testRunfileEnhanced.sh
